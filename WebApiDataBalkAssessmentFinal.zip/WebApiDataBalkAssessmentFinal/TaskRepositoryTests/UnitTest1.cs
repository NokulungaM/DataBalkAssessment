namespace TestProjectTaskRepositoryTests;

using System;
using System.Collections.Generic;
using System.Linq;
using Moq;
using Xunit;

namespace WebApiDataBalkAssessmentFinal.Tests.Repositories
{
    public class TaskRepositoryTests
    {
        [Fact]
        public void GetExpiredTasks_ReturnsExpiredTasks()
        {
            // Arrange
            var today = DateTime.Today;
            var expiredTasks = new List<Task>
            {
                new Task { ID = 1, DueDate = today.AddDays(-1) },
                new Task { ID = 2, DueDate = today.AddDays(-2) }
            };

            var contextMock = new Mock<DataContext>();
            contextMock.Setup(c => c.Tasks).Returns(expiredTasks.AsQueryable());

            var repository = new TaskRepository(contextMock.Object);

            // Act
            var result = repository.GetExpiredTasks();

            // Assert
            Assert.Equal(expiredTasks.Count, result.Count());
            Assert.All(result, t => Assert.True(t.DueDate < today));
        }

        [Fact]
        public void GetActiveTasks_ReturnsActiveTasks()
        {
            // Arrange
            var today = DateTime.Today;
            var activeTasks = new List<Task>
            {
                new Task { ID = 1, DueDate = today.AddDays(1) },
                new Task { ID = 2, DueDate = today.AddDays(2) }
            };

            var contextMock = new Mock<DataContext>();
            contextMock.Setup(c => c.Tasks).Returns(activeTasks.AsQueryable());

            var repository = new TaskRepository(contextMock.Object);

            // Act
            var result = repository.GetActiveTasks();

            // Assert
            Assert.Equal(activeTasks.Count, result.Count());
            Assert.All(result, t => Assert.True(t.DueDate >= today));
        }

        [Fact]
        public void GetTasksFromDate_ReturnsTasksFromDate()
        {
            // Arrange
            var targetDate = DateTime.Today.AddDays(3);
            var tasksFromDate = new List<Task>
            {
                new Task { ID = 1, DueDate = targetDate.AddDays(1) },
                new Task { ID = 2, DueDate = targetDate.AddDays(2) }
            };

            var contextMock = new Mock<DataContext>();
            contextMock.Setup(c => c.Tasks).Returns(tasksFromDate.AsQueryable());

            var repository = new TaskRepository(contextMock.Object);

            // Act
            var result = repository.GetTasksFromDate(targetDate);

            // Assert
            Assert.Equal(tasksFromDate.Count, result.Count());
            Assert.All(result, t => Assert.True(t.DueDate >= targetDate));
        }
    }
}
