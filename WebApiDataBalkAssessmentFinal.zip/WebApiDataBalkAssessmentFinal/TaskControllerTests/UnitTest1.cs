namespace TaskControllerTests;

// TaskControllerTests.cs
using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;

namespace WebApiDataBalkAssessmentFinal.Tests.Controllers
{
    public class TaskControllerTests
    {
        [Fact]
        public void GetTasks_ReturnsTasks()
        {
            // Arrange
            var mockRepository = new Mock<TaskRepository>();
            var controller = new TaskController(mockRepository.Object);

            // Act
            var result = controller.GetTasks();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var tasks = Assert.IsType<List<Task>>(okResult.Value);
            Assert.NotNull(tasks);
        }

        [Fact]
        public void GetTask_ExistingTask_ReturnsTask()
        {
            // Arrange
            var taskId = 1;
            var mockRepository = new Mock<TaskRepository>();
            mockRepository.Setup(repo => repo.GetTaskById(taskId))
                          .Returns(new Task { ID = taskId, Title = "Test Task", DueDate = DateTime.Now });

            var controller = new TaskController(mockRepository.Object);

            // Act
            var result = controller.GetTask(taskId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var task = Assert.IsType<Task>(okResult.Value);
            Assert.Equal(taskId, task.ID);
        }

        [Fact]
        public void GetTask_NonExistingTask_ReturnsNotFound()
        {
            // Arrange
            var taskId = 1;
            var mockRepository = new Mock<TaskRepository>();
            mockRepository.Setup(repo => repo.GetTaskById(taskId)).Returns((Task)null);

            var controller = new TaskController(mockRepository.Object);

            // Act
            var result = controller.GetTask(taskId);

            // Assert
            Assert.IsType<NotFoundResult>(result);
        }
        
    }
}
