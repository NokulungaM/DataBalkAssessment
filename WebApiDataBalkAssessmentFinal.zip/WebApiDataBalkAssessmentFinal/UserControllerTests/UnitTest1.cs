namespace UserControllerTests;

// UserControllerTests.cs
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;

namespace WebApiDataBalkAssessmentFinal.Tests.Controllers
{
    public class UserControllerTests
    {
        [Fact]
        public void GetUsers_ReturnsUsers()
        {
            // Arrange
            var controller = new UserController();

            // Act
            var result = controller.GetUsers();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var users = Assert.IsType<List<User>>(okResult.Value);
            Assert.Equal(0, users.Count);
        }

        [Fact]
        public void GetUser_ExistingUser_ReturnsUser()
        {
            // Arrange
            var controller = new UserController();
            var userId = 1;
            controller.CreateUser(new User { ID = userId, Username = "TestUser", Email = "test@example.com", Password = "password" });

            // Act
            var result = controller.GetUser(userId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var user = Assert.IsType<User>(okResult.Value);
            Assert.Equal(userId, user.ID);
        }

        [Fact]
        public void GetUser_NonExistingUser_ReturnsNotFound()
        {
            // Arrange
            var controller = new UserController();
            var userId = 1;

            // Act
            var result = controller.GetUser(userId);

            // Assert
            Assert.IsType<NotFoundResult>(result);
        }

        [Fact]
        public void CreateUser_ReturnsCreatedResponse()
        {
            // Arrange
            var controller = new UserController();
            var newUser = new User { Username = "NewUser", Email = "newuser@example.com", Password = "newpassword" };

            // Act
            var result = controller.CreateUser(newUser);

            // Assert
            var createdAtActionResult = Assert.IsType<CreatedAtActionResult>(result);
            var user = Assert.IsType<User>(createdAtActionResult.Value);
            Assert.Equal(1, user.ID);
        }
        
    }
}
