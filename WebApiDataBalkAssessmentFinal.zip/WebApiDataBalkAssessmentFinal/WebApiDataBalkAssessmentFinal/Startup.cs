namespace WebApiDataBalkAssessmentFinal;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Authentication;

public class Startup
{

    public void ConfigureServices(IServiceCollection services)
    {
        

        services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            .AddJwtBearer(options =>
                services.AddDbContext<DataContext>();
        
    }

                {
                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuer = true,
                        ValidateAudience = true,
                        ValidateLifetime = true,
                        ValidateIssuerSigningKey = true,
                        ValidIssuer = "DataBalk",           
                        ValidAudience = "WeThinkCode",      
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("Nokulunga123")) 
                    };

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseAuthentication();
            
        
        services.AddAuthentication("ApiKey")
            .AddApiKey(options =>
            {
                options.Events = new ApiKeyAuthenticationEvents
                {
                    OnValidateKey = context =>
                    {
                        // Validate the API key here
                        // Example: Check if the key exists in your database

                        if (context.ApiKey == "YourUniqueApiKey")
                        {
                            context.ValidationSucceeded();
                        }
                        else
                        {
                            context.ValidationFailed();
                        }

                        return Task.CompletedTask;
                    }
                };
            });





   

