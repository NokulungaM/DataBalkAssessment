namespace WebApiDataBalkAssessmentFinal.Controllers;



using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;

[Route("api/[controller]")]
[ApiController]
public class TaskController : ControllerBase
{
    private readonly TaskRepository _taskRepository;

    public TaskController(TaskRepository taskRepository)
    {
        _taskRepository = taskRepository;
    }

    [HttpGet]
    public ActionResult<IEnumerable<Task>> GetTasks()
    {
        var tasks = _taskRepository.GetTasks();
        return Ok(tasks);
    }

    [HttpGet("{id}")]
    public ActionResult<Task> GetTask(int id)
    {
        var task = _taskRepository.GetTaskById(id);
        if (task == null)
            return NotFound();
        return Ok(task);
    }

    [HttpPost]
    public ActionResult<Task> CreateTask(Task task)
    {
        _taskRepository.AddTask(task);
        return CreatedAtAction(nameof(GetTask), new { id = task.ID }, task);
    }

    [HttpPut("{id}")]
    public ActionResult<Task> UpdateTask(int id, Task task)
    {
        var existingTask = _taskRepository.GetTaskById(id);
        if (existingTask == null)
            return NotFound();

        _taskRepository.UpdateTask(task);
        return Ok(task);
    }

    [HttpDelete("{id}")]
    public ActionResult<Task> DeleteTask(int id)
    {
        var task = _taskRepository.GetTaskById(id);
        if (task == null)
            return NotFound();

        _taskRepository.DeleteTask(id);
        return Ok(task);
    }

    [HttpGet("expired")]
    public ActionResult<IEnumerable<Task>> GetExpiredTasks()
    {
        var expiredTasks = _taskRepository.GetExpiredTasks();
        return Ok(expiredTasks);
    }

    [HttpGet("active")]
    public ActionResult<IEnumerable<Task>> GetActiveTasks()
    {
        var activeTasks = _taskRepository.GetActiveTasks();
        return Ok(activeTasks);
    }

    [HttpGet("fromDate/{date}")]
    public ActionResult<IEnumerable<Task>> GetTasksFromDate(DateTime date)
    {
        var tasksFromDate = _taskRepository.GetTasksFromDate(date);
        return Ok(tasksFromDate);
    }
}
