namespace WebApiDataBalkAssessmentFinal.Controllers;

using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;



[Authorize(AuthenticationSchemes = "ApiKey")]
[Route("api/[controller]")]
[ApiController]
public class UserController : ControllerBase
{
    private static List<User> users = new List<User>();

    [HttpGet]
    public ActionResult<IEnumerable<User>> GetUsers()
    {
        return Ok(users);
    }

    [HttpGet("{id}")]
    public ActionResult<User> GetUser(int id)
    {
        var user = users.Find(u => u.ID == id);
        if (user == null)
            return NotFound();
        return Ok(user);
    }

    [HttpPost]
    public ActionResult<User> CreateUser(User user)
    {
        user.ID = users.Count + 1;
        users.Add(user);
        return CreatedAtAction(nameof(GetUser), new { id = user.ID }, user);
    }

    [HttpPut("{id}")]
    public ActionResult<User> UpdateUser(int id, User user)
    {
        var existingUser = users.Find(u => u.ID == id);
        if (existingUser == null)
            return NotFound();

        existingUser.Username = user.Username;
        existingUser.Email = user.Email;
        existingUser.Password = user.Password;

        return Ok(existingUser);
    }

    [HttpDelete("{id}")]
    public ActionResult<User> DeleteUser(int id)
    {
        var user = users.Find(u => u.ID == id);
        if (user == null)
            return NotFound();

        users.Remove(user);
        return Ok(user);
    }
}
   
   