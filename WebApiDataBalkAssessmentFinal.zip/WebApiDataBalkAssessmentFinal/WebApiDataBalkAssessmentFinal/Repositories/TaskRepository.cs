namespace WebApiDataBalkAssessmentFinal.Repositories;

using System;
using System.Collections.Generic;
using System.Linq;

public class TaskRepository
{
    private readonly DataContext _context;

    public TaskRepository(DataContext context)
    {
        _context = context;
    }

 
    public IEnumerable<Task> GetExpiredTasks()
    {
        var today = DateTime.Today;
        return _context.Tasks.Where(t => t.DueDate < today).ToList();
    }

    public IEnumerable<Task> GetActiveTasks()
    {
        var today = DateTime.Today;
        return _context.Tasks.Where(t => t.DueDate >= today).ToList();
    }

    public IEnumerable<Task> GetTasksFromDate(DateTime date)
    {
        return _context.Tasks.Where(t => t.DueDate >= date).ToList();
    }
}
