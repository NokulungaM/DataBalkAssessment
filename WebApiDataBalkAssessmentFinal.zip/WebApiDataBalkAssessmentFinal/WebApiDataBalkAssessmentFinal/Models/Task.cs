namespace WebApiDataBalkAssessmentFinal.Models;

public class Task
{
    public int ID { get; set; }
    public string Title { get; set; }
    public string Description { get; set; }
    public int Assignee { get; set; } // Assuming Assignee is the UserID
    public DateTime DueDate { get; set; }
}